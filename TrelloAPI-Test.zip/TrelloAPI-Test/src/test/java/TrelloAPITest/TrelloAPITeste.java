package TrelloAPITest;
import org.junit.Assert;
import org.junit.Before;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import static io.restassured.RestAssured.given;
import org.hamcrest.Matchers;
import static org.hamcrest.Matchers.*;
import io.restassured.response.Response;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)

public class TrelloAPITeste {

	    /******************* API Key e API Token devem ser informados para execu��o do teste ****************/
		public static String apiKey = "0eec7f9e832e2eb2fdf8a85182fd572e";
		public static String apiToken = "3f4242dd658263df35ea0b0c26e3f55db9b5149fb615c395a613db5c495a9a19";
		/****************************************************************************************************/
		
		// inicializando variaveis
		public static String idCard = "";
		public static String idBoard = "";
		public static String idList = "";
		
		//variaveis body
		public static String name = "Tarefa 01";
		public static String descricao = "Descri��o da tarefa 01";
		public static String nameAlt = "Tarefa 01 Alterado";
		public static String descricaoAlt = "Descri��o da tarefa 01 Alterado";
		
		// Lista inv�lida
		public static String idListInvalid = "XXXXXXXXXXXXXXXXXXXXXXX";
		
		// Url base
		@Before
	    public void setup() {
	        RestAssured.baseURI = "https://api.trello.com/";
		}
		
		// Acesso concedido
	   @Test
	    public void test01DadoqueEuAcessoOTrelloComMeuAPIKeyEAPIToken(){

		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("1/members/me/boards?key={yourKey}&token={yourToken}", apiKey ,apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(200, response.statusCode());		   
	        
	    }
	   
	   /************** Cria novo board e lista para ser utilizado no teste **************/
	   @Test
	   public void test02criaNovoBoard(){
		   
		   String id = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .post("1/boards/?name=Desafio&key={yourKey}&token={yourToken}", apiKey,  apiToken)
	                .prettyPeek().jsonPath().getString("id").toString();

		   idBoard = id;
	    }
	   
	   @Test
	   public void test03RecuperaNovoBoard(){
	   Response response = given()
               .contentType(ContentType.JSON)
               .when()
               .get("1/boards/{idBoard}?key={yourKey}&token={youtToken}", idBoard, apiKey, apiToken)
               .then()
               .extract().response();
	   
	   Assert.assertEquals(200, response.statusCode());	
	   }
	   
	   @Test
	   public void test04criaListaDoNovoBoard(){
		   
		   System.out.println("ID do Board:" + idBoard);
		   
		   String id = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .post("1/boards/{id}/lists?name=ListaDesafio&key={yourKey}&token={youtToken}", idBoard, apiKey, apiToken)
	                .prettyPeek().jsonPath().getString("id").toString();	
		   
		   idList = id; 
	    }
	   
	   @Test
	   public void test05RecuperaListaDoNovoBoard(){
	   Response response = given()
               .contentType(ContentType.JSON)
               .when()
               .get("1/lists/{idList}?key={yourKey}&token={youtToken}", idList, apiKey, apiToken)
               .then()
               .extract().response();
	   
	   Assert.assertEquals(200, response.statusCode());	
	   }
	   
	   /**************************************************************************************/
	   
	   // Cria novo card
	   @Test
	   public void test06QuandoeuSolicitoACriacaoDeUmNovoCardNaLista(){
		   
		   String id = given()
	                .contentType(ContentType.JSON)
	                .body("{ \"name\" :  \"" + name + "\" , \"desc\": \"" + descricao + "\" , \"idList\": \"" + idList	+ "\"}")
	                .when()
	                .post("1/cards/?idList={idList}&key={yourKey}&token={yourToken}", idList, apiKey,  apiToken)
	                .prettyPeek().jsonPath().getString("id").toString();
		   
		   idCard = id;
		   
	    }
	   
	   // Verifica se o card foi criado
	   @Test
	   public void test07EntaoOCardECriado(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("1/cards/{id}?key={yourKey}&token={youtToken}", idCard, apiKey, apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(200, response.statusCode());	
		   
	    }	     
	   
	   // Edita card
	   @Test
	   public void test08DadoQueeuSolicitoUmaAlteracaoNoNomeDoCardEntaoOCardEAlterado(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .body("{ \"name\" :  \"" + nameAlt + "\" , \"desc\": \"" + descricaoAlt + "\" , \"idList\": \"" + idList	+ "\"}")
	                .when()
	                .put("1/cards/{id}?key={yourKey}&token={yourToken}", idCard, apiKey,  apiToken)
	                .then()
	                .body("name", Matchers.is(nameAlt))
	    			.body("desc",Matchers. is(descricaoAlt))
	                .extract().response();
		   
		   Assert.assertEquals(200, response.statusCode());	
		   
	    }
	     
	   
	   // oIdDaListaInformadoEInexistente
	   @Test
	   public void test09QuandoeuSolicitoACriacaoDeUmNovoCardComIdListaInexistenteEntaoNaoCriaCard(){
		   
		    given()
	                .contentType(ContentType.JSON)
	                .when()
	                .post("1/cards/?idList={idList}&key={yourKey}&token={yourToken}", idListInvalid, apiKey,  apiToken)
	                .then()
	                .statusCode(400)
	                .body(is("invalid value for idList"));
		   
	    }
	   

	   // Exclui card
	   @Test
	   public void test10QuandoEuSolicitoUmaExclusaoDoCard(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .delete("1/cards/{id}?key={yourKey}&token={yourToken}", idCard, apiKey,  apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(200, response.statusCode());	
		   
	    }
	   
	   // o Card E Excluido
	   @Test
	   public void test11EntaoOCardEExcluido(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("1/cards/{id}?key={yourKey}&token={youtToken}", idCard, apiKey, apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(404, response.statusCode());	
		   
	    }
	   
	// Exclui Board
	   @Test
	   public void test12QuandoEuSolicitoUmaExclusaoDoBoard(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .delete("1/boards/{id}?key={yourKey}&token={yourToken}", idBoard, apiKey,  apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(200, response.statusCode());	
		   
	    }
	   
	   // o Board E Excluido
	   @Test
	   public void test13EntaoOBoardEExcluido(){
		   
		   Response response = given()
	                .contentType(ContentType.JSON)
	                .when()
	                .get("1/boards/{id}?key={yourKey}&token={youtToken}", idBoard, apiKey, apiToken)
	                .then()
	                .extract().response();
		   
		   Assert.assertEquals(404, response.statusCode());	
		   
	    }
	   
}
